package com.capgemini.lesson9;

public enum Gender {
      M, F,
}